# HW4
The basic command for running the code is

    python3 main.py --type <question_number>

## q1
```
    python3 main.py --type 1
```

- This opens up a dialog window with the triangulated point cloud for the monument
- The camera matrices for both the cameras and the rotation and translation for the camera 2 gets printed on the terminal window

## q2
```
    python3 main.py --type 2
```
- This opens up a dialog window with the reconstruction for the camera 1 and 2 comes up
- Closing this opens up the dialog window for the reconstrction after adding camera 3
- Closing this opens up the dialog window for the reconstrction after adding camera 4
- Closing this last one, prints the rotation and translations for camera 3 and 4 on the terminal window



### For more information

    python3 main.py --help